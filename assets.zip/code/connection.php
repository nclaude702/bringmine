<?php
$host="localhost";
$user="root";
$pass="";
$db="bringmine";
$con=new pdo("mysql:host=$host;dbname=$db;",$user,$pass);


 ?>